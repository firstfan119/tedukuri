#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
char a[maxn], b[maxn];
int x[maxn], y[maxn], z[maxn];

void str2int(char m[], int n[]){   //mת�������n 
	int len;
	len = strlen(m);		
	for(int i=0; i<len; i++)	//ת��
		n[len-i] = m[i] - '0';
}

int main(){
	scanf("%s%s", a, b);
	int len, flag = 1; 
	if(strcmp(a, b) >= 0){
		str2int(a, x);
		str2int(b, y);
		len = strlen(a);
	}
	else{
		str2int(b, x);
		str2int(a, y);
		len = strlen(b);
		flag = -1;
	}
    for(int i=1; i<=len; i++)    //��λ���
        z[i] = x[i] - y[i];
    for(int i=1; i<=len; i++)
		if(z[i] < 0){	//������λ
			z[i] += 10;
			z[i+1] -= 1;
		}
    while((len > 1) && (z[len] == 0)) //�������λ
        len--;
    if(flag == -1) printf("-");
    for(int i=len; i>=1; i--)
    	printf("%d", z[i]);
    return 0;
}

