#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
char a[maxn], b[maxn];
int x[maxn], y[maxn], z[maxn];

void str2int(char m[], int n[]){   //mת�������n 
	int len;
	len = strlen(m);		
	for(int i=0; i<len; i++)	//ת��
		n[len-i] = m[i] - '0';
}

int main(){
	scanf("%s%s", a, b);
	int lena, lenb, len;
	lena = strlen(a);
	lenb = strlen(b);
	str2int(a, x);
	str2int(b, y);
	if(lena > lenb) len = lena;//��͵�λ��
    else  len = lenb;
    for(int i=1; i<=len; i++)    //��λ���
        z[i] = x[i] + y[i];
    len++;                    //λ����1
    for(int i=1; i<len; i++){     //������λ
        z[i+1] += z[i] / 10;
        z[i] %= 10;
    }
    while((len > 1) && (z[len] == 0)) //�������λ
        len--;
    for(int i=len; i>=1; i--)
    	printf("%d", z[i]);
    return 0;
}

